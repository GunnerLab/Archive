#!/usr/bin/python2

# program name and location
WebServer = 'WEBSERVER_IP'

CGI = "http://%s/cgi-bin/tools.py?" % WebServer
INDEXPAGE = "http://%s/cgi-bin/index.py" % WebServer

# Debug support
import cgitb; cgitb.enable()

# Get passed in variables from URL
import cgi, os, Cookie
form = cgi.FieldStorage()

class CONFORMER:
   def __init__(self):
      self.occ = []

class E_IONIZE:
   def __init__(self):
      self.mfe = []

# color table
NONPOLAR = "#B0B0B0"    # grey
POLAR    = "#FFFF80"    # yellow
POSITIVE = "#7070FF"    # blue
NEGATIVE = "#FF7070"    # red
UNKNOWN  = "#B0B0B0"    # light grey


color_table = {"GLY": NONPOLAR,
               "ALA": NONPOLAR,
               "VAL": NONPOLAR,
               "LEU": NONPOLAR,
               "ILE": NONPOLAR,
               "SER": POLAR,
               "THR": POLAR,
               "CYS": NEGATIVE,
               "MET": POLAR,
               "PRO": POLAR,
               "ASP": NEGATIVE,
               "ASN": POLAR,
               "GLU": NEGATIVE,
               "GLN": POLAR,
               "LYS": POSITIVE,
               "ARG": POSITIVE,
               "HIS": POSITIVE,
               "PHE": NONPOLAR,
               "TYR": NEGATIVE,
               "TRP": POLAR,
               "HOH": NEGATIVE,
               "HEM": POSITIVE,
               "PAA": NEGATIVE,
               "PDD": NEGATIVE,
               "NTR": POSITIVE,
               "NTG": POSITIVE,
               "CTR": NEGATIVE,
               "UbQ": NEGATIVE,
               "RSB": POSITIVE,
               "CUA": POSITIVE,
               "CUB": POSITIVE,
               "HEA": POSITIVE,
               "HA0": POSITIVE,
               "TYF": POSITIVE,
               "_CU": POSITIVE,
               "HA3": POSITIVE,
               "HEB": POSITIVE,
               "_CA": POSITIVE
}




# page prototypes
PROTOTYPE_head="""
   <html>
   <head><title> MCCE analysis </title></head>
   <body bgcolor = white>
   <p><h2> MCCE analysis on _REALNAME_ (path:_DIRECTORY_):</h2> </p>
"""

PROTOTYPE_tail="""
   <hr>
   <p align=right>Copyright &copy; Gunner's Group 2003</p>
   </body>
   </html>
"""

PROTOTYPE_index=PROTOTYPE_head+"""
   <p>0. <a href=%s>Welcome Page</a></br>
   1. MCCE analysis on _REALNAME_</p>
   <hr>
_THRESHOLD_
_TITRATION_TABLE_
"""%(INDEXPAGE)+PROTOTYPE_tail

PROTOTYPE_confmfe=PROTOTYPE_head+"""
   <p>0. <a href=%s>Welcome Page</a><br>
   1. <a href=_CGI_directory=_DIRECTORY_&name=_NAME_>MCCE analysis on 
_REALNAME_</a><br>
   2. Conformer energy analysis
   </p>
   <hr>
_THRESHOLD_
_CONFMFE_
"""%(INDEXPAGE)+PROTOTYPE_tail

PROTOTYPE_resmfe=PROTOTYPE_head+"""
   <p>0. <a href=%s>Welcome Page</a><br>
   1. <a href=_CGI_directory=_DIRECTORY_&name=_NAME_ target=_top>MCCE analysis on _REALNAME_</a><br>
   2. Group ionization energy analysis </p> <hr>
_OUTSTR_
   </body>
   </html>
"""%(INDEXPAGE)

conformers = []
titration_range = []
titration_type = ""
titration_unit = ""
show_status = []
mfe_status = []
refine_index = -0.0001
refine_mfe   = -0.0001
unit = "Kcal/mol"
ph1 = 7.0
eh1 = 0.0
ph2Kcal = 1.364
mev2Kcal = 0.0235
Kcal2kT  = 1.688
residues = []
cscale = 1.0
scale_ele = 1.0
scale_vdw = 1.0
scale_vdw0  = 1.0
scale_vdw1  = 1.0
scale_tors  = 1.0
scale_dsolv = 1.0
fname_extra = ""

def weighted_color(color, weight):
   "Convert color to weighted color, weight is between 0 and."
   if weight > 1.0: weight = 1.0

   #cut color (#RRGGBB) into 3 pecieces
   RR = color[1:3]
   GG = color[3:5]
   BB = color[5:7]

   if (int(RR, 16) < 255):
      rr = "%02X" % (255-(255-int(int(RR, 16)))*weight)
   else:
      rr = RR

   if (int(GG,16) < 255):
      gg = "%02X" % (255-(255-int(int(GG,16)))*weight)
   else:
      gg = GG

   if (int(BB,16) < 255):
      bb = "%02X" % (255-(255-int(int(BB,16)))*weight)
   else:
      bb = BB

   return "#"+rr+gg+bb


def first_ph():
   global ph1, eh1, scale_ele, scale_vdw, scale_vdw0, scale_vdw1, scale_tors, scale_dsolv,fname_extra
   lines=open(form["directory"].value + "/run.prm").readlines()
   for line in lines:
      if    line.find("(TITR_PH0)")>=0:
         ph1 = float(line.split()[0])
      elif line.find("(TITR_EH0)")>=0:
         eh1 = float(line.split()[0])
      elif line.find("(EXTRA)")>=0:
         fname_extra = line.split()[0]

   
   if fname_extra:
      if fname_extra[0] == '/':
         lines=open(fname_extra).readlines()
      else:
         lines=open(form["directory"].value + '/' +fname_extra).readlines()
      
      for line in lines:
         fields = line.split()
         if len(fields) != 3:
	    continue  
	 elif fields[0]+fields[1] == "SCALINGVDW0":
	    scale_vdw0 = float(fields[2])
	 elif fields[0]+fields[1] == "SCALINGVDW1":
	    scale_vdw1 = float(fields[2])
	 elif fields[0]+fields[1] == "SCALINGVDW":
	    scale_vdw = float(fields[2])
	 elif fields[0]+fields[1] == "SCALINGTORS":
	    scale_tors = float(fields[2])
	 elif fields[0]+fields[1] == "SCALINGELE":
	    scale_ele = float(fields[2])
	 elif fields[0]+fields[1] == "SCALINGDSOLV":
	    scale_dsolv = float(fields[2])
	     
   for line in lines:
      if   line.find("(SCALE_ELE)")>=0:
         scale_ele = float(line.split()[0])
      elif line.find("(SCALE_VDW)")>=0:
         scale_vdw  = float(line.split()[0])
         scale_vdw0 = scale_vdw
         scale_vdw1 = scale_vdw

   return


def read_headlst():
   global conformers
   global titration_range,titration_type,titration_unit, scale_ele, scale_vdw

   lines = open(form["directory"].value+"/head3.lst").readlines()
   lines.pop(0)   # remove the title line

   if len(conformers) > 0:
      print "WARNING: adding to non empty conformer list."

   for line in lines:
      fields = line.split()
      conformer = CONFORMER()
      conformer.id   = fields[1]
      conformer.crg  = float(fields[4])
      conformer.Em0  = float(fields[5])
      conformer.pKa0 = float(fields[6])
      conformer.ne   = int(fields[7])
      conformer.nH   = int(fields[8])
      conformer.vdw0 = float(fields[9]) * scale_vdw0
      conformer.vdw1 = float(fields[10])* scale_vdw1
      conformer.tors = float(fields[11])* scale_tors
      conformer.epol = float(fields[12])* scale_ele
      conformer.dsolv= float(fields[13])* scale_dsolv
      conformer.extra= float(fields[14])
      conformer.self = conformer.vdw0+conformer.vdw1+conformer.tors+conformer.epol+conformer.dsolv+conformer.extra
      conformers.append(conformer)
   return

def read_fort38():
   global conformers
   global titration_range,titration_type,titration_unit

   lines = open(form["directory"].value+"/fort.38").readlines()

   temp = lines[0].split()
   ttype = temp[0].strip().upper()
   if   ttype == 'EH':
      titration_type = 'Eh'
      titration_unit = 'mV'
   elif ttype == 'PH':
      titration_type = 'pH'
      titration_unit = 'pH'
   else:
      titration_type = ttype
      titration_unit = '?'
   titration_range = [float(x) for x in temp[1:]]
   lines.pop(0)

   for i in range(len(conformers)):
      line = lines[i].split()
      if conformers[i].id != line[0]:
         print "ERROR, %s in head3.lst doesn't match %s in fort.38" %(conformers[i].id, line[0])
         return
      conformers[i].occ = [float(x) for x in line[1:]]

   return

def group_residues():
   global conformers
   global titration_range,titration_type,titration_unit

   residues = []

   if len(conformers) < 1: return residues    # no conformers
   old_resid = conformers[0].id[:3] + conformers[0].id[5:11]
   residue = [old_resid, [], []]
   if conformers[0].id[3] == '0' or conformers[0].id[3] == 'D':
      residue[1].append(conformers[0])
   else:
      residue[2].append(conformers[0])

   for conformer in conformers[1:]:
      current_resid = conformer.id[:3] + conformer.id[5:11]
      if current_resid == old_resid:
         if conformer.id[3] == '0' or conformer.id[3] == 'D':
            residue[1].append(conformer)
         else:
            residue[2].append(conformer)
      else: # a new residue
         residues.append(residue)
         old_resid = current_resid
         residue = [old_resid, [], []]
         if conformer.id[3] == '0':
            residue[1].append(conformer)
         else:
            residue[2].append(conformer)

   residues.append(residue)

   return residues

def read_pK():
   lines = open(form["directory"].value+"/pK.out").readlines()
   pK = [[line[:10], line[10:]] for line in lines]
   return pK

def update_links(in_str):
   out_str = in_str.replace("_CGI_", CGI)
   out_str = out_str.replace("_DIRECTORY_", form["directory"].value)
   out_str = out_str.replace("_REALNAME_", form["name"].value)
   name = form["name"].value.replace(" ", "%20") # URL deosn't accept " "
   out_str = out_str.replace("_NAME_", name)

   return out_str

def print_index():
   global conformers
   global titration_range,titration_type,titration_unit
   global show_status
   global refine_index
   global ph1, eh1
   global residues

   # compose out cookie
   show_string = ''
   for c in show_status: show_string += c
   out_cookie = Cookie.SimpleCookie()
   out_cookie["mcce"] = form["directory"].value + ':' + show_string + ':%.2f' % refine_index
   print 'Content-Type: text/html'
   print '%s\n\n' % out_cookie


   # form to accept refine display variables
   threshold  = '<form name=refine method=get action=' + CGI + '>\n'
   threshold += '<input type=hidden name=directory value="' + form["directory"].value + '">'
   threshold += '<input type=hidden name=name  value="' + form["name"].value + '">'
   threshold += '<input type=hidden name=action value=refine_index>'

   if titration_type == 'Eh':
      ev = 'pH'
      ew = ph1
   else:
      ev = 'Eh'
      ew = eh1
   threshold += '%s titration at %s %.1f, displayed at threshold <input type=text name=refine_index size=10 value=%.2f>&nbsp;' % (titration_type, ev, ew, refine_index+0.001)
   threshold += '<input type=submit name=submit value=Submit>\n'
   threshold += '</form>\n'


   width = 100.0/(len(titration_range)+1)

   outstr  = '<pre>'
   outstr += '<table cellpadding="1" cellspacing="1" border="2" width="100%">\n'
   outstr += '<tbody>\n'

   # First row, title
   outstr += '<tr>\n'
   outstr += '<td>%s(%s) '%(titration_type, titration_unit)
   outstr += '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=expand_index><img src=/mcceimages/expandall.gif border="0"></a> \n'    
   outstr += '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=collapse_index><img src=/mcceimages/collapseall.gif border="0"></a> \n'
   outstr += '</td>\n'
   for x in titration_range:
      if titration_type == 'Eh':
         outstr += '<td align = "right">' + "%5.0f" % x
      else:
         outstr += '<td align = "right">' + "%5.1f" % x
      outstr += '</td>\n'
   outstr += '</tr>\n'

   sum_netcrg   = [0.0 for x in range(len(titration_range))]
   sum_proton   = [0.0 for x in range(len(titration_range))]
   sum_electron = [0.0 for x in range(len(titration_range))]

   # residues

   for i in range(len(residues)):
      residue = residues[i]
      if color_table.has_key(residue[0][:3]):
         color = color_table[residue[0][:3]]
      else:
         color = UNKNOWN

      netcrg   = [0.0 for x in range(len(titration_range))]
      for conf in residue[2]:
         for j in range(len(conf.occ)):
            netcrg[j]       += conf.occ[j] * conf.crg
            sum_netcrg[j]   += conf.occ[j] * conf.crg
            sum_proton[j]   += conf.occ[j] * conf.nH
            sum_electron[j] += conf.occ[j] * conf.ne

      # skip this residue if the maximum abolute vale of net charge is < refine_index
      anetcrg = [abs(x) for x in netcrg]
      if max(anetcrg) < refine_index: continue

      # net charge line
      url = '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=toggle_index&value=%d>' % i

      if show_status[i] == 't':
         ec_button = '<img src = /mcceimages/collapse.gif alt="collapse" border=0>'
      else:
         ec_button = '<img src = /mcceimages/expand.gif alt="expand" border=0>'

      outstr += '<tr>\n'

      if color == POSITIVE or color == NEGATIVE:  # use color gradient to represent net charge, add mfe button
         outstr += '<td align = "left" bgcolor ='+color+'>' + residue[0] + url + ec_button+'</a>' + '<a href=_CGI_directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%d&ea=false&eb=false&ia=0&ib=vdw0>'%i+'<img src = /mcceimages/energies.gif alt="energies" border=0></a>'+ '</td>\n'        
         for x in netcrg:
            outstr += '<td align = "right" bgcolor='+weighted_color(color, abs(x))+'>' + "%5.2f" % x + '</td>\n'
      else:                                       # plain color
         outstr += '<td align = "left" bgcolor ='+color+'>' + residue[0] + url + ec_button + '</a>' + '</td>\n'
         for x in netcrg:
            outstr += '<td align = "right" bgcolor='+color+'>' + "%5.2f" % x + '</td>\n'

      outstr += '</tr>\n'

      # show conformer
      if show_status[i] == "t":
         for conformer in residue[1]+residue[2]:
            # skip this conformer if the maximum occupance is < refine_index
            if max(conformer.occ) < refine_index: continue

            outstr += '<tr>\n'
            url = '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=confmfe&value=%s>' % conformer.id.replace('+','%2B')
            outstr += '<td align = "right"><font color=#20a020>' + conformer.id +url+'<img src = /mcceimages/energies.gif alt="energies" border=0></font></td>\n'
            for x in conformer.occ:
               outstr += '<td align = "right"><font color=#20a020>' + "%5.2f" % x + '</font></td>\n'
            outstr += '</tr>\n'

   outstr += '<tr><td valign="top" rowspan="1" colspan="' + "%d"%(len(titration_range)+1)+ '"><br></td></tr><tr>'

   outstr += '<tr>\n'
   outstr += '<th align = "left"> <b> Net Charge </b></th>\n'
   for x in sum_netcrg:
      outstr += '<th align = "right">' + "%5.2f" % x + '</th>\n'
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<th align = "left"> <b> Protons </b></th>\n'
   for x in sum_proton:
      outstr += '<th align = "right">' + "%5.2f" % x + '</th>\n'
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<th align = "left"> <b> Electrons </b></th>\n'
   for x in sum_electron:
      outstr += '<th align = "right">' + "%5.2f" % x + '</th>\n'
   outstr += '</tr>\n'

   outstr += '</tbody>\n'
   outstr += '</table>\n'
   outstr += '</pre>\n'


   outstr += 'Color Legend: <br>'

   outstr += '<table cellpadding="0" cellspacing="5" border="0" width="20%">\n'
   outstr += '<tbody>\n'

   outstr += '<tr>\n'
   outstr += '<td bgcolor =' + NONPOLAR + '>&nbsp;</td>\n'
   outstr += '<td>Nonpolar</td>\n'
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td bgcolor =' + POLAR + '>&nbsp;</td>\n'
   outstr += '<td>Polar</td>\n'
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td bgcolor =' + POSITIVE + '>&nbsp;</td>\n'
   outstr += '<td>Positive</td>\n'
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td bgcolor =' + NEGATIVE + '>&nbsp;</td>\n'
   outstr += '<td>Negative</td>\n'
   outstr += '</tr>\n'

   outstr += '</tbody>\n'
   outstr += '</table>\n'

   # list raw data file
   outstr += '<p>Experts may view or download these raw data files:<br>\n'
   outstr += '<ul>\n'
   outstr += '<li><a href=' + CGI + 'directory=_DIRECTORY_&action=view&name=_NAME_&value=fort.38><img src=/mcceimages/view.gif alter=view border=0></a> <a href=' + CGI + 'directory=_DIRECTORY_&action=save&name=_NAME_&value=fort.38><img src=/mcceimages/save.gif alter=save border=0></a> fort.38</a></li>\n'
   outstr += '<li><a href=' + CGI + 'directory=_DIRECTORY_&action=view&name=_NAME_&value=pK.out><img src=/mcceimages/view.gif alter=view border=0></a> <a href=' + CGI + 'directory=_DIRECTORY_&action=save&name=_NAME_&value=pK.out><img src=/mcceimages/save.gif alter=save border=0></a> pK.out</a></li>\n'
   outstr += '<li><a href=' + CGI + 'directory=_DIRECTORY_&action=view&name=_NAME_&value=head3.lst><img src=/mcceimages/view.gif alter=view border=0></a> <a href=' + CGI + 'directory=_DIRECTORY_&action=save&name=_NAME_&value=head3.lst><img src=/mcceimages/save.gif alter=save border=0></a> head3.lst</a></li>\n'
   outstr += '<li><a href=' + CGI + 'directory=_DIRECTORY_&action=view&name=_NAME_&value=sum_crg.out><img src=/mcceimages/view.gif alter=view border=0></a> <a href=' + CGI + 'directory=_DIRECTORY_&action=save&name=_NAME_&value=sum_crg.out><img src=/mcceimages/save.gif alter=save border=0></a> sum_crg.out</a></li>\n'
   outstr += '</ul></p>\n'



   outpage = PROTOTYPE_index
   outpage = outpage.replace("_THRESHOLD_", threshold)
   outpage = outpage.replace("_TITRATION_TABLE_", outstr)

   outpage = update_links(outpage)
   print outpage
   return

def print_confmfe():
   "Energy analysis for a conformer."

   global conformers
   global titration_range,titration_type,titration_unit
   global refine_mfe
   global unit
   global ph1, eh1
   global ph2Kcal, mevKcal
   global residues
   global mfe_status
   global cscale, scale_vdw, scale_ele

   # color has to be a positive value
   if cscale < 0.000001: cscale = 0.000001

   if   unit == 'Kcal/mol': Kcal2unit=1.000
   elif unit == 'kT':       Kcal2unit=1.688
   elif unit == 'pH':       Kcal2unit=0.733
   elif unit == 'meV':      Kcal2unit=42.51
   else:                    Kcal2unit=1.000


   separate_color = '#B0B0B0'

   # compose out cookie
   out_cookie1 = Cookie.SimpleCookie()
   out_cookie1["refine_mfe"] = form["directory"].value + ':%.2f' % refine_mfe
   out_cookie2 = Cookie.SimpleCookie()
   out_cookie2["select_unit"] = form["directory"].value + ':%s' % unit
   out_cookie3 = Cookie.SimpleCookie()
   show_string = ''
   for x in mfe_status: show_string += x
   out_cookie3["mfe_status"] = form["directory"].value+':%s' % form["value"].value.replace('+', '%2B') + ':%s' % show_string
   out_cookie4 = Cookie.SimpleCookie()
   out_cookie4["cscale"] = '%.2f' % cscale
   print 'Content-Type: text/html'
   print '%s\n%s\n%s\n%s\n\n' % (out_cookie1, out_cookie2, out_cookie3, out_cookie4)

   # form to accept refine display variables
   if titration_type=='Eh':
      ev = ph1
      ew = 'pH'
   else:
      ev = eh1
      ew = 'mV'
   threshold  = '<p>MFE energy analysis of conformer %s at %.1f %s :</p>\n' % (form["value"].value, ev, ew)
   threshold += '<form name=refine method=get action=' + CGI + '>\n'
   threshold += '<input type=hidden name=directory value="' + form["directory"].value + '">\n'
   threshold += '<input type=hidden name=name  value="' + form["name"].value + '">\n'
   threshold += '<input type=hidden name=action value="refine_mfe">\n'
   threshold += '<input type=hidden name=value value=%s>\n' % form["value"].value.replace('%2B', '+')
   threshold += '<input type=hidden name=lastaction value=print_confmfe>'
   threshold += 'Display at: threshold = <input type=text name=refine_mfe size=10 value=%.2f>&nbsp;\n' % (refine_mfe+0.0001)
   threshold += 'full color at: <input type=text name=cscale value=%.2f size=10>\n' % cscale

   # form to accept energy unit
   # show a list of possible units.
   threshold += 'unit = \n'
   threshold += '<select size=1 name=select_unit>\n'

   if (unit == "Kcal/mol"):
      threshold += '  <option value="Kcal/mol" selected>Kcal/mol</option>\n'
   else:
      threshold += '  <option value="Kcal/mol">Kcal/mol</option>\n'
   if (unit == "kT"):
      threshold += '  <option value=%s selected>%s' % (unit, unit) + '</option>\n'
   else:
      threshold += '  <option value=kT>kT</option>\n'
   if (unit == "pH"):
      threshold += '  <option value=pH selected>pH</option>\n'
   else:
      threshold += '  <option value=pH>pH</option>\n'
   if (unit == "meV"):
      threshold += '  <option value=meV selected>meV</option>\n'
   else:
      threshold += '  <option value=meV>meV</option>\n'

   threshold += '</select>\n'
   threshold += '<input type=submit name=submit value=Submit>\n'
   threshold += '</form>\n'
   outstr = ''

   # prepare a table
   width = 100.0/(len(titration_range)+1)
   outstr += '<pre>'
   outstr += '<table cellpadding="1" cellspacing="1" border="2" width="100%">\n'
   outstr += '<tbody>\n'

   head3lst = open(form["directory"].value+"/head3.lst").readlines()
   E_self = []
   for line in head3lst:
      fields = line.split()
      if fields[1] == form["value"].value.replace("%2B", "+"):
         E_self = [float(x) for x in fields[3:]]
         E_self[6] *= scale_vdw
         E_self[7] *= scale_vdw
         E_self[9] *= scale_ele
         E_self[12] = E_self[6]+E_self[7]+E_self[8]+E_self[9]+E_self[10]+E_self[11]
         break

   # section 1 of the table: conformer property
   outstr += '<tr><td colspan=%d bgcolor=%s>Conformer (%s) properties</td></tr>' % (len(titration_range)+1, separate_color, form["value"].value.replace("%2B","+"))
   if E_self: # this line valid
      number = '%8.3f' % E_self[1]
      outstr += '<tr><td>charge</td><td colspan=%d align=center>%s</td></tr>\n'% (len(titration_range), number.replace(' ', '&nbsp;'))
      number = '%8.3f' % E_self[2]
      outstr += '<tr><td>Em0</td>   <td colspan=%d align=center>%s</td></tr>\n'% (len(titration_range), number.replace(' ', '&nbsp;'))
      number = '%8.3f' % E_self[3]
      outstr += '<tr><td>pKa0</td>  <td colspan=%d align=center>%s</td></tr>\n'% (len(titration_range), number.replace(' ', '&nbsp;'))
      number = '%8.3f' % E_self[4]
      outstr += '<tr><td>ne-</td>   <td colspan=%d align=center>%s</td></tr>\n'% (len(titration_range), number.replace(' ', '&nbsp;'))
      number = '%8.3f' % E_self[5]
      outstr += '<tr><td>nH+</td>   <td colspan=%d align=center>%s</td></tr>\n'% (len(titration_range), number.replace(' ', '&nbsp;'))

   # section 2 of the table: self energy
   outstr += '<tr><td colspan=%d bgcolor=%s>Non-pH/Eh sensitive energy (self energy)</td></tr>\n' % (len(titration_range)+1, separate_color)
   if E_self: # this line valid
      E = E_self[6]*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      number = '%8.3f' % E
      outstr += '<tr><td>vdw0</td><td colspan=%d align=center bgcolor=%s>%s</td></tr>\n' % (len(titration_range), color, number.replace(' ','&nbsp;'))

      E = E_self[7]*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      number = '%8.3f' % E
      outstr += '<tr><td>vdw1</td><td colspan=%d align=center bgcolor=%s>%s</td></tr>\n' % (len(titration_range), color,number.replace(' ','&nbsp;'))

      E = E_self[8]*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      number = '%8.3f' % E
      outstr += '<tr><td>torsion</td><td colspan=%d align=center bgcolor=%s>%s</td></tr>\n' % (len(titration_range),color, number.replace(' ', '&nbsp;'))

      E = E_self[9]*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      number = '%8.3f' % E
      outstr += '<tr><td>ebackbon</td><td colspan=%d align=center bgcolor=%s>%s</td></tr>\n' % (len(titration_range), color,number.replace(' ', '&nbsp;'))

      E = E_self[10]*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      number = '%8.3f' % E
      outstr += '<tr><td>dsolv</td><td colspan=%d align=center bgcolor=%s>%s</td></tr>\n' % (len(titration_range), color,number.replace(' ', '&nbsp;'))

      E = E_self[11]*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      number = '%8.3f' % E
      outstr += '<tr><td>offset</td><td colspan=%d align=center bgcolor=%s>%s</td></tr>\n' % (len(titration_range), color,number.replace(' ', '&nbsp;'))

   # pH/Eh sensitive energies and total
   # Title line
   outstr += '<tr><td colspan=%d bgcolor=%s>%s sensitive energies '% (len(titration_range)+1, separate_color, titration_type)
   outstr += '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=expand_mfe&value=%s><img src=/mcceimages/expandall.gif border="0"></a>\n' % form["value"].value.replace('+', '%2B')
   outstr += '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=collapse_mfe&value=%s><img src=/mcceimages/collapseall.gif border="0"></a>\n' % form["value"].value.replace('+', '%2B')
   outstr += '</td></tr>'
   width = 100.0/(len(titration_range)+1)
   outstr += '<tr>\n'
   outstr += '<td><font color=#20a020>' + titration_type + '</font></td>'
   for x in titration_range:
      if titration_type == 'Eh':
         outstr += '<td align = "right" width=%.2f%%>'%width + "<font color=#20a020>%5.0f</font>" % x
      else:
         outstr += '<td align = "right" width=%.2f%%>'%width + "<font color=#20a020>%5.1f</font>" % x
      outstr += '</td>\n'
   outstr += '</tr>\n'
   outstr += '<tr><td colspan=%d bgcolor=%s></td></tr>' % (len(titration_range)+1, separate_color)

   # pH-pKa0
   outstr += '<tr>\n'
   outstr += '<td align=left>pH-pKa0</td>\n'
   for x in titration_range:
      if titration_type == 'pH':
         number = (x-E_self[3])*E_self[5]*ph2Kcal*Kcal2unit+0.0000001
      else:
         number = (ph1-E_self[3])*E_self[5]*ph2Kcal*Kcal2unit + 0.0000001

      if number>0: color  = weighted_color(POSITIVE, number/cscale)
      else:   color  = weighted_color(NEGATIVE, -number/cscale)

      if unit == 'meV':
         outstr += '<td align=right bgcolor=%s>%.1f</td>\n' % (color,number)
      else:
         outstr += '<td align=right bgcolor=%s>%.2f</td>\n' % (color, number)
   outstr += '</tr>\n'

   # Eh-Em0
   outstr += '<tr>\n'
   outstr += '<td align=left>Eh-Em0</td>\n'
   for x in titration_range:
      if titration_type == 'Eh':
         number = (x-E_self[2])*E_self[4]*mev2Kcal*Kcal2unit+0.000001
      else:
         number = (eh1-E_self[2])*E_self[4]*mev2Kcal*Kcal2unit + 0.000001

      if number>0: color  = weighted_color(POSITIVE, number/cscale)
      else:   color  = weighted_color(NEGATIVE, -number/cscale)

      if unit == 'meV':
         outstr += '<td align=right bgcolor=%s>%.1f</td>\n' % (color, number)
      else:
         outstr += '<td align=right bgcolor=%s>%.2f</td>\n' % (color, number)
   outstr += '</tr>\n'

   # section 3 of the table: mfe from residues
   # pairwise energy table
   pairwise = {}
   if form["value"].value[3:5] == "DM":
      pass
      for x in [conformers[i].id for i in range(len(conformers))]:
         pairwise[x] = 0.0
   else:
      lines = open(form["directory"].value+"/energies/"+form["value"].value+".opp").readlines()
      for line in lines:
         line = line.split()
         if len(line) == 4:
            pairwise[line[1]] = float(line[2])*scale_ele + float(line[3])*scale_vdw

   # handle residue line
   outstr += '<tr><td colspan=%d bgcolor=%s></td></tr>' % (len(titration_range)+1, separate_color)
   total = [0.0 for x in range(len(titration_range))]

   confid = form["value"].value
   current_residue_id = confid[:3]+confid[5:11]

   for i in range(len(residues)):
      residue = residues[i]

      resE  = [0.0 for x in range(len(titration_range))]

      if residue[0] == current_residue_id:
         resE = [x*Kcal2unit for x in resE] # convert to display unit
         aresE = [abs(x) for x in resE]
         if max(aresE) < refine_mfe: continue

         outstr += '<tr>\n'
         outstr += '<td align =left>' + residue[0] + '</td>\n'

         for x in resE:
            outstr += '<td align =right>' + "%5.2f" % 0.0 + '</td>\n'
         outstr += '</tr>\n'
         continue

      for conf in residue[1]+residue[2]:
         for j in range(len(titration_range)):
            if not pairwise.has_key(conf.id):pairwise[conf.id] = 0.0 # dummy conformer
            resE[j]  += conf.occ[j] * pairwise[conf.id]*Kcal2unit
            total[j] += conf.occ[j] * pairwise[conf.id]*Kcal2unit

      # skip this residue if the maximum abolute value of net charge is < refine_index
      aresE = [abs(x) for x in resE]
      if max(aresE) < refine_mfe: continue

      # res mfe line
      if mfe_status[i] == 't':
         ec_button = '<img src = /mcceimages/collapse.gif alt="collapse" border=0>'
      else:
         ec_button = '<img src = /mcceimages/expand.gif alt="expand" border=0>'
      url = '<a href=' + CGI + 'directory=_DIRECTORY_&name=_NAME_&action=toggle_mfe&value=%s&i=%d>' % (form["value"].value.replace('+', '%2B'),i)
      outstr += '<tr>\n'
      outstr += '<td align =left>' + residue[0] + url + ec_button + '</a></td>\n'
      for x in resE:
         if x>0: color  = weighted_color(POSITIVE, x/cscale)
         else:   color  = weighted_color(NEGATIVE, -x/cscale)

         if unit == 'meV':
            outstr += '<td align =right bgcolor=%s>'%color + "%5.1f" % x + '</td>\n'
         else:
            outstr += '<td align =right bgcolor=%s>'%color + "%5.2f" % x + '</td>\n'
      outstr += '</tr>\n'

      # show conformer
      if mfe_status[i] == "t":
         for conformer in residue[1]+residue[2]:
            if not pairwise.has_key(conformer.id): pairwise[conformer.id] = 0.0
            confE  = [occ*pairwise[conformer.id]*Kcal2unit for occ in conformer.occ]
            aconfE = [abs(x) for x in confE]
            # skip this conformer if the maximum occupance is < refine_index
            if max(aconfE) < refine_mfe: continue

            outstr += '<tr>\n'
            outstr += '<td align =right><font color=#20a020>' + conformer.id + '</font></td>\n'
            for x in confE:
               if unit == 'meV':
                  outstr += '<td align =right><font color=#20a020>' + "%5.1f" % x + '</font></td>\n'
               else:
                  outstr += '<td align =right><font color=#20a020>' + "%5.2f" % x + '</font></td>\n'
            outstr += '</tr>\n'

   # section 4, pairwise subtotal
   outstr += '<tr>\n'
   outstr += '<td align =left><font color=#20a020>Res_total</font></td>\n'
   for x in total:

      if x>0: color  = weighted_color(POSITIVE, x/cscale)
      else:   color  = weighted_color(NEGATIVE, -x/cscale)

      if unit == 'meV':
         outstr += '<td align =right bgcolor=%s>'%color + "<font color=#20a020>%5.1f</font>" % x + '</td>\n'
      else:
         outstr += '<td align =right bgcolor=%s>'%color + "<font color=#20a020>%5.2f</font>" % x + '</td>\n'
   outstr += '</tr>\n'

   # total conf energy
   outstr += '<tr><td colspan=%d bgcolor=%s></td></tr>' % (len(titration_range)+1, separate_color)
   outstr += '<tr>\n'
   outstr += '<td align =left><b>Total</b></td>\n'
   for i in range(len(titration_range)):
      E = total[i]+E_self[12]*Kcal2unit
      if titration_type == 'pH': # pH effect
         E+= (titration_range[i]-E_self[3])*E_self[5]*ph2Kcal*Kcal2unit
      else:
         E+= (ph1-E_self[3])*E_self[5]*ph2Kcal*Kcal2unit
      if titration_type == 'Eh': # eh effect
         E+= (titration_range[i]-E_self[2])*E_self[4]*mev2Kcal*Kcal2unit
      else:
         E+= (eh1-E_self[2])*E_self[4]*mev2Kcal*Kcal2unit


      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)

      if unit == 'meV':
         outstr += '<td align =right bgcolor=%s>'%color + "<b>%5.1f</b>" % E + '</td>\n'
      else:
         outstr += '<td align =right bgcolor=%s>'%color + "<b>%5.2f</b>" % E + '</td>\n'

   outstr += '</tr>\n'
   outstr += '</tbody>\n'
   outstr += '</table>\n'
   outstr += '</pre>\n'

   outstr += '<font color=#20a020>Numbers in green don\'t contribute to the total.</font>'

   outpage = PROTOTYPE_confmfe
   outpage = outpage.replace("_THRESHOLD_", threshold)
   outpage = outpage.replace("_CONFMFE_", outstr)
   outpage = outpage.replace("_CONFORMERID_", form["value"].value)
   outpage = outpage.replace("_UNIT_", titration_unit)

   outpage = update_links(outpage)
   print outpage
   return

def E_ionize(residue):
   global residues
   import math

   dG_ionize = E_IONIZE()

   # mfe for each conformer
   for conformer in residue[1]+residue[2]:
      conformer.pHeffect = [0.0 for i in range(len(titration_range))]
      conformer.Eheffect = [0.0 for i in range(len(titration_range))]
      conformer.res_mfe =  [[0.0 for i in range(len(titration_range))] for x in residues]
      conformer.mfe_total= [0.0 for i in range(len(titration_range))]
      conformer.E_total =  [0.0 for i in range(len(titration_range))]

      # pairwise energy table
      pairwise = {}
      if conformer.id[3:5] == "DM":
         pass
         #for x in [conformers[i].id for i in range(len(conformers))]:
         #   pairwise[x] = 0.0

      else:
         lines = open(form["directory"].value+"/energies/"+conformer.id+".opp").readlines()
         for line in lines:
            line = line.split()
            if len(line) == 4:
               pairwise[line[1]] = float(line[2])*scale_ele + float(line[3])*scale_vdw

      # make conformer mfe
      for i in range(len(titration_range)):
         point = titration_range[i]
         conf_mfe = [0.0 for x in titration_range]

         # pH effect in Kcal/mol
         if titration_type == 'pH':
            conformer.pHeffect[i] = (point-conformer.pKa0)*conformer.nH*ph2Kcal
         else:
            conformer.pHeffect[i] = (ph1-conformer.pKa0)*conformer.nH*ph2Kcal

         # Eh effect in Kcal/mol
         if titration_type == 'Eh':
            conformer.Eheffect[i] = (point-conformer.Em0)*conformer.ne*mev2Kcal
         else:
            conformer.Eheffect[i] = (eh1-conformer.Em0)*conformer.ne*mev2Kcal

         for j in range(len(residues)):
            res = residues[j]
            if res[0] == residue[0]:
               mfe = 0.0
            else:
               mfe = 0.0
               for conf in res[1]+res[2]:
                  if not pairwise.has_key(conf.id):pairwise[conf.id] = 0.0
                  mfe+=pairwise[conf.id]*conf.occ[i]
            # This mfe is at 1 titration point, from one residue
            conformer.res_mfe[j][i] = mfe
            conformer.mfe_total[i] += mfe

         # update conformer E_total
         conformer.E_total[i] = conformer.mfe_total[i]\
                                +conformer.pHeffect[i]\
                                +conformer.Eheffect[i]\
                                +conformer.self


   Eref=residue[1][0].E_total[0]    # reference E (lowest of this res)
   for conf in residue[1]+residue[2]:
      for i in range(len(titration_range)):
         if Eref > conf.E_total[i]: Eref=conf.E_total[i]

   # Calculate mfe occupancy of each conformer
   SigmaE = [0.0 for i in range(len(titration_range))]
   for i in range(len(titration_range)):
      Ei = [math.exp(-(conformer.E_total[i]-Eref)*Kcal2kT) for conformer in residue[1]+residue[2]]
      for x in Ei: SigmaE[i] += x

   for conformer in residue[1]+residue[2]:
      conformer.rocc = [0.0 for x in titration_range]
      for i in range(len(titration_range)):
         conformer.rocc[i] = math.exp(-(conformer.E_total[i]-Eref)*Kcal2kT)/SigmaE[i]  # recovered occ

   SigmaOcc = [0.0 for i in range(len(titration_range))]
   for conformer in residue[1]:
      for i in range(len(titration_range)):SigmaOcc[i] += conformer.rocc[i]
   for conformer in residue[1]:
      conformer.nocc = [conformer.rocc[i]/SigmaOcc[i] for i in range(len(titration_range))]

   SigmaOcc = [0.0 for i in range(len(titration_range))]
   for conformer in residue[2]:
      for i in range(len(titration_range)):SigmaOcc[i] += conformer.rocc[i]
   for conformer in residue[2]:
      conformer.nocc = [conformer.rocc[i]/SigmaOcc[i] for i in range(len(titration_range))]


   # energy terms of ground state
   ground_state = E_IONIZE()
   ground_state.vdw0  = [0.0 for x in titration_range]
   ground_state.vdw1  = [0.0 for x in titration_range]
   ground_state.tors  = [0.0 for x in titration_range]
   ground_state.epol  = [0.0 for x in titration_range]
   ground_state.dsolv = [0.0 for x in titration_range]
   ground_state.extra = [0.0 for x in titration_range]
   ground_state.pHeffect= [0.0 for x in titration_range]
   ground_state.Eheffect= [0.0 for x in titration_range]
   ground_state.mfe_total=[0.0 for x in titration_range]
   ground_state.res_mfe = [[0.0 for x in titration_range] for x in residues]
   ground_state.E_total  =[0.0 for x in titration_range]
   ground_state.TS       =[0.0 for x in titration_range]
   for conformer in residue[1]:
      for i in range(len(titration_range)):
         ground_state.vdw0[i]     += conformer.nocc[i]*conformer.vdw0
         ground_state.vdw1[i]     += conformer.nocc[i]*conformer.vdw1
         ground_state.tors[i]     += conformer.nocc[i]*conformer.tors
         ground_state.epol[i]     += conformer.nocc[i]*conformer.epol
         ground_state.dsolv[i]    += conformer.nocc[i]*conformer.dsolv
         ground_state.extra[i]   += conformer.nocc[i]*conformer.extra
         ground_state.pHeffect[i] += conformer.nocc[i]*conformer.pHeffect[i]
         ground_state.Eheffect[i] += conformer.nocc[i]*conformer.Eheffect[i]
         ground_state.mfe_total[i]+= conformer.nocc[i]*conformer.mfe_total[i]
         ground_state.E_total[i]  += conformer.nocc[i]*conformer.E_total[i]
         if conformer.nocc[i]>0.000001:
            ground_state.TS[i]       +=-conformer.nocc[i]*math.log(conformer.nocc[i])/Kcal2kT
      for j in range(len(residues)):
         for i in range(len(titration_range)):
            ground_state.res_mfe[j][i] += conformer.nocc[i]*conformer.res_mfe[j][i]

   ground_state.G = [ground_state.E_total[i] - ground_state.TS[i] for i in range(len(titration_range))]

   # energy terms of charged state
   charged_state = E_IONIZE()
   charged_state.vdw0  = [0.0 for x in titration_range]
   charged_state.vdw1  = [0.0 for x in titration_range]
   charged_state.tors  = [0.0 for x in titration_range]
   charged_state.epol  = [0.0 for x in titration_range]
   charged_state.dsolv = [0.0 for x in titration_range]
   charged_state.extra = [0.0 for x in titration_range]
   charged_state.pHeffect= [0.0 for x in titration_range]
   charged_state.Eheffect= [0.0 for x in titration_range]
   charged_state.res_mfe = [[0.0 for x in titration_range] for x in residues]
   charged_state.mfe_total=[0.0 for x in titration_range]
   charged_state.E_total  =[0.0 for x in titration_range]
   charged_state.TS       =[0.0 for x in titration_range]
   for conformer in residue[2]:
      for i in range(len(titration_range)):
         charged_state.vdw0[i]     += conformer.nocc[i]*conformer.vdw0
         charged_state.vdw1[i]     += conformer.nocc[i]*conformer.vdw1
         charged_state.tors[i]     += conformer.nocc[i]*conformer.tors
         charged_state.epol[i]     += conformer.nocc[i]*conformer.epol
         charged_state.dsolv[i]    += conformer.nocc[i]*conformer.dsolv
         charged_state.extra[i]   += conformer.nocc[i]*conformer.extra
         charged_state.pHeffect[i] += conformer.nocc[i]*conformer.pHeffect[i]
         charged_state.Eheffect[i] += conformer.nocc[i]*conformer.Eheffect[i]
         charged_state.mfe_total[i]+= conformer.nocc[i]*conformer.mfe_total[i]
         charged_state.E_total[i]  += conformer.nocc[i]*conformer.E_total[i]
         if conformer.nocc[i]>0.000001:
            charged_state.TS[i]       +=-conformer.nocc[i]*math.log(conformer.nocc[i])/Kcal2kT
      for j in range(len(residues)):
         for i in range(len(titration_range)):
            charged_state.res_mfe[j][i] += conformer.nocc[i]*conformer.res_mfe[j][i]

   charged_state.G = [charged_state.E_total[i] - charged_state.TS[i] for i in range(len(titration_range))]

   dG_ionize.ground_state = ground_state
   dG_ionize.charged_state = charged_state
   dG_ionize.ground_confs = residue[1]
   dG_ionize.charged_confs = residue[2]
   dG_ionize.resID = residue[0]

   return dG_ionize

def print_resmfe():
   global titration_range,titration_type,titration_unit
   global refine_mfe
   global unit
   global ph1, eh1
   global ph2Kcal, mevKcal
   global residues
   global cscale
   
   import math

   # color has to be a positive value
   if cscale < 0.000001: cscale = 0.000001

   if   unit == 'Kcal/mol': Kcal2unit=1.000
   elif unit == 'kT':       Kcal2unit=1.688
   elif unit == 'pH':       Kcal2unit=0.733
   elif unit == 'meV':      Kcal2unit=42.51
   else:                    Kcal2unit=1.000

   dG = E_ionize(residues[int(form["value"].value)])
   # compose out cookie
   out_cookie1 = Cookie.SimpleCookie()
   out_cookie1["refine_mfe"] = form["directory"].value + ':%.2f' % refine_mfe
   out_cookie2 = Cookie.SimpleCookie()
   out_cookie2["select_unit"] = form["directory"].value + ':%s' % unit
   out_cookie4 = Cookie.SimpleCookie()
   out_cookie4["cscale"] = '%.2f' % cscale

   print 'Content-Type: text/html'
   print '%s\n%s\n%s\n\n' % (out_cookie1, out_cookie2, out_cookie4)

   # form to accept refine display variables
   if titration_type=='Eh':
      ev = ph1
      ew = 'pH'
   else:
      ev = eh1
      ew = 'mV'
   outstr  = '<p>Ionization energy analysis of group %s at %.1f %s :</p>\n' % (residues[int(form["value"].value)][0], ev, ew)
   outstr += '<form name=refine method=get action=' + CGI + '>\n'
   outstr += '<input type=hidden name=directory value="' + form["directory"].value + '">\n'
   outstr += '<input type=hidden name=name  value="' + form["name"].value + '">\n'
   outstr += '<input type=hidden name=action value="refine_mfe">\n'
   outstr += '<input type=hidden name=lastaction value="print_resmfe">\n'
   outstr += '<input type=hidden name=ia value=%s>\n' % form["ia"].value
   outstr += '<input type=hidden name=ib value=%s>\n' % form["ib"].value
   outstr += '<input type=hidden name=ea value=%s>\n' % form["ea"].value
   outstr += '<input type=hidden name=eb value=%s>\n' % form["eb"].value
   outstr += '<input type=hidden name=value value=%s>\n' % form["value"].value.replace('%2B', '+')
   outstr += 'Display at: threshold = <input type=text name=refine_mfe size=10 value=%.2f>&nbsp;\n' % (refine_mfe+0.0001)
   outstr += 'full color at: <input type=text name=cscale value=%.2f size=10>\n' % cscale
   outstr += 'unit = \n'
   outstr += '<select size=1 name=select_unit>\n'
   if (unit == "Kcal/mol"):
      outstr += '  <option value="Kcal/mol" selected>Kcal/mol</option>\n'
   else:
      outstr += '  <option value="Kcal/mol">Kcal/mol</option>\n'
   if (unit == "kT"):
      outstr += '  <option value=%s selected>%s' % (unit, unit) + '</option>\n'
   else:
      outstr += '  <option value=kT>kT</option>\n'
   if (unit == "pH"):
      outstr += '  <option value=pH selected>pH</option>\n'
   else:
      outstr += '  <option value=pH>pH</option>\n'
   if (unit == "meV"):
      outstr += '  <option value=meV selected>meV</option>\n'
   else:
      outstr += '  <option value=meV>meV</option>\n'
   outstr += '</select>\n'
   outstr += '<input type=submit name=submit value=Submit>\n'
   outstr += '</form>\n'

   # prepare a table
   width = 100.0/(len(titration_range)+1)
   outstr += '<pre>'
   outstr += '<table cellpadding="1" cellspacing="1" border="2" width="100%">\n'
   outstr += '<tbody>\n'

   separate_color = '#B0B0B0'

   # title line
   outstr += '<tr bgcolor=%s>\n'%separate_color
   outstr += '<td align = left> %s(%s)</td>'%(titration_type, titration_unit)
   for x in titration_range:
      if titration_type == 'Eh':
         outstr += '<td align = "right" width=%.2f%%>'%width + "%5.0f" % x
      else:
         outstr += '<td align = "right" width=%.2f%%>'%width + "%5.1f" % x
      outstr += '</td>\n'
   outstr += '</tr>\n'


   # MC net charge
   outstr += '<tr>\n'
   outstr += '<td align = left> Ionization(MC)</td>'
   for i in range(len(titration_range)):
      netcrg = 0.0
      for conf in dG.charged_confs: netcrg += conf.occ[i]
      outstr += '<td align = "right">%4.2f</td>\n' % netcrg
   outstr += '</tr>\n'

   # MFE net charge
   outstr += '<tr>\n'
   outstr += '<td align = left> Ionization(MFE)</td>'
   for i in range(len(titration_range)):
      netcrg = 0.0
      for conf in dG.charged_confs: netcrg += conf.rocc[i]
      outstr += '<td align = "right">%4.2f</td>\n' % netcrg
   outstr += '</tr>\n'

   # dG
   outstr += '<tr>\n'
   outstr += '<td align = left> <b>DeltaG</b></td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.G[i]-dG.ground_state.G[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s><b>%4.2f</b></td>\n' % (color, E)
   outstr += '</tr>\n'

   # Breakdown terms
   outstr += '<tr><td colspan=%d bgcolor=%s>Breakdown energy terms</td></tr>' % (len(titration_range)+1, separate_color)

   outstr += '<tr>\n'
   outstr += '<td align = left>vdw0</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.vdw0[i]-dG.ground_state.vdw0[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>vdw1</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.vdw1[i]-dG.ground_state.vdw1[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>Torsion</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.tors[i]-dG.ground_state.tors[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>Ebkb</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.epol[i]-dG.ground_state.epol[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>Desolvation</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.dsolv[i]-dG.ground_state.dsolv[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>Offset</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.extra[i]-dG.ground_state.extra[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'
   outstr += '<tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>pH_effect</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.pHeffect[i]-dG.ground_state.pHeffect[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>Eh_effect</td>'
   for i in range(len(titration_range)):
      E=(dG.charged_state.Eheffect[i]-dG.ground_state.Eheffect[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   outstr += '<td align = left>-T*deltaS</td>'
   for i in range(len(titration_range)):
      E=-(dG.charged_state.TS[i]-dG.ground_state.TS[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E+0.000001)
   outstr += '</tr>\n'

   outstr += '<tr>\n'
   url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&eb=%s' % (form["value"].value, form["ia"].value, form["ib"].value, form["eb"].value)
   if not form.has_key("ea") or form["ea"].value == 'false':
      url+='&ea=true'
      icon = '/mcceimages/expand.gif'
   else:
      url+='&ea=false'
      icon = '/mcceimages/collapse.gif'

   outstr += '<td align = left>Residues<a href=%s><img src=%s align=bottom border=0></a></td>' % (url, icon)
   for i in range(len(titration_range)):
      E=(dG.charged_state.mfe_total[i]-dG.ground_state.mfe_total[i])*Kcal2unit
      if E>0: color  = weighted_color(POSITIVE, E/cscale)
      else:   color  = weighted_color(NEGATIVE, -E/cscale)
      outstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
   outstr += '</tr>\n'


   # residues
   if form.has_key("ea") and form["ea"].value == "true":
      for j in range(len(dG.ground_state.res_mfe)):
         tmpstr  = '<tr>\n'
         tmpstr += '<td align=right>%s</td>' % residues[j][0]
         aE = 0.0
         for i in range(len(titration_range)):
            E=(dG.charged_state.res_mfe[j][i]-dG.ground_state.res_mfe[j][i])*Kcal2unit
            if E>0: color  = weighted_color(POSITIVE, E/cscale)
            else:   color  = weighted_color(NEGATIVE, -E/cscale)
            tmpstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
            if aE < abs(E): aE = abs(E)
         tmpstr += '</tr>\n'
         if aE > refine_mfe: outstr+=tmpstr

   # Details Pointer
   outstr += '<tr>'
   outstr += '<td></td>'
   p = int(form["ia"].value)
   for i in range(len(titration_range)):
      if p != i:
         url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%d&ib=%s&ea=%s&eb=%s'%(form["value"].value, i, form["ib"].value, form["ea"].value, form["eb"].value)
         icon = '/mcceimages/down_u.gif'
         outstr += '<td align=center><a href=%s><img src=%s border=0 alt=no></a></td>' % (url, icon)
      else:
         icon = '/mcceimages/down_p.gif'
         outstr += '<td align =center><img src=%s border=0 alt=yes></td>' % icon

   outstr += '</tr>'

   outstr += '</tbody>\n'
   outstr += '</table>\n'
   outstr += '</pre>\n'


   # The lower portion of the page, zoom in report
   outstr += '<pre>'
   outstr += '<table cellpadding="1" cellspacing="5" border="0" width="100%">\n'
   outstr += '<tbody>\n'

   # Left portion
   outstr += '<tr><td width=50% valign=top>' # start of the left lower portion
   outstr += 'Analysis at specific pH and Eh:'

   outstr += '<table cellpadding="1" cellspacing="1" border="2" width=100%>\n'
   outstr += '<tbody>\n'
   outstr += '<tr bgcolor=%s>\n'%separate_color
   if titration_type == 'Eh':
      outstr += '<td>pH=%.1f Eh=%.0f</td>'%(ph1, titration_range[int(form["ia"].value)])
   else:
      outstr += '<td>pH=%.1f Eh=%.0f</td>'%(titration_range[int(form["ia"].value)], eh1)

   outstr += '<td align=center> Ground state </td>'
   outstr += '<td align=center> Charged state </td>'
   outstr += '<td colspan=2 align=center> Delta </td>'
   outstr += '</tr>'

   i=int(form["ia"].value)

   # dG
   outstr += '<tr>\n'
   outstr += '<td align = left><b>DeltaG</b></td>'

   E=dG.ground_state.G[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s><b>%.2f</b></td>\n' % (color, E)

   E=dG.charged_state.G[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s><b>%.2f</b></td>\n' % (color, E)

   E=(dG.charged_state.G[i]-dG.ground_state.G[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td colspan=2 align = "right" bgcolor=%s><b>%.2f</b></td>\n' % (color, E)
   
   outstr += '</tr>\n'


   # vdw0
   outstr += '<tr>\n'
   outstr += '<td align = left>vdw0</td>'

   E=dG.ground_state.vdw0[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.vdw0[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.vdw0[i]-dG.ground_state.vdw0[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "vdw0": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "vdw0", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # vdw1
   outstr += '<tr>\n'
   outstr += '<td align = left>vdw1</td>'

   E=dG.ground_state.vdw1[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.vdw1[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.vdw1[i]-dG.ground_state.vdw1[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "vdw1": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "vdw1", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # tors
   outstr += '<tr>\n'
   outstr += '<td align = left>Torsion</td>'

   E=dG.ground_state.tors[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.tors[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.tors[i]-dG.ground_state.tors[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "tors": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "tors", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # epol
   outstr += '<tr>\n'
   outstr += '<td align = left>Ebkb</td>'

   E=dG.ground_state.epol[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.epol[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.epol[i]-dG.ground_state.epol[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "epol": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "epol", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # dsolv
   outstr += '<tr>\n'
   outstr += '<td align = left>Desolvation</td>'

   E=dG.ground_state.dsolv[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.dsolv[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.dsolv[i]-dG.ground_state.dsolv[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "dsolv": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "dsolv", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'


   # offset
   outstr += '<tr>\n'
   outstr += '<td align = left>Offset</td>'

   E=dG.ground_state.extra[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.extra[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.extra[i]-dG.ground_state.extra[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "offset": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "offset", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'


   # pH
   outstr += '<tr>\n'
   outstr += '<td align = left>pH_effect</td>'

   E=dG.ground_state.pHeffect[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.pHeffect[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.pHeffect[i]-dG.ground_state.pHeffect[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "pH": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "pH", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # Eh
   outstr += '<tr>\n'
   outstr += '<td align = left>Eh_effect</td>'

   E=dG.ground_state.Eheffect[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.Eheffect[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.Eheffect[i]-dG.ground_state.Eheffect[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "Eh": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "Eh", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # -TS
   outstr += '<tr>\n'
   outstr += '<td align = left>-TS</td>'

   E=-dG.ground_state.TS[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E+0.000001)

   E=-dG.charged_state.TS[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E+0.000001)

   E=-(dG.charged_state.TS[i]-dG.ground_state.TS[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E+0.000001)

   if form["ib"].value != "TS": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "TS", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   # residues
   url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s' % (form["value"].value, form["ia"].value, form["ib"].value, form["ea"].value)
   if not form.has_key("eb") or form["eb"].value == 'false':
      url+='&eb=true'
      icon = '/mcceimages/expand.gif'
   else:
      url+='&eb=false'
      icon = '/mcceimages/collapse.gif'

   outstr += '<td align = left>Residues<a href=%s><img src=%s align=bottom border=0></a></td>' % (url, icon)

   E=dG.ground_state.mfe_total[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=dG.charged_state.mfe_total[i]*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   E=(dG.charged_state.mfe_total[i]-dG.ground_state.mfe_total[i])*Kcal2unit
   if E>0: color  = weighted_color(POSITIVE, E/cscale)
   else:   color  = weighted_color(NEGATIVE, -E/cscale)
   outstr += '<td align = "right" bgcolor=%s>%.2f</td>\n' % (color, E)

   if form["ib"].value != "residues": 
      url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, "residues", form["ea"].value, form["eb"].value)
      icon = '<img src=/mcceimages/right_u.gif border=0>'
      outstr += '<td><a href=%s>%s</a></td>' % (url, icon)
   else:
      icon = '<img src=/mcceimages/right_p.gif border=0>'
      outstr += '<td>%s</td>' % icon

   outstr += '</tr>\n'

   if form.has_key("eb") and form["eb"].value == "true":
      for j in range(len(residues)):
         tmpstr  = '<tr>\n'
         tmpstr += '<td align=right>%s</td>' % residues[j][0]

         E=dG.ground_state.res_mfe[j][i]*Kcal2unit
         if E>0: color  = weighted_color(POSITIVE, E/cscale)
         else:   color  = weighted_color(NEGATIVE, -E/cscale)
         tmpstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
         aE = abs(E)

         E=dG.charged_state.res_mfe[j][i]*Kcal2unit
         if E>0: color  = weighted_color(POSITIVE, E/cscale)
         else:   color  = weighted_color(NEGATIVE, -E/cscale)
         tmpstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
         if aE < abs(E): aE=abs(E)

         E=(dG.charged_state.res_mfe[j][i]-dG.ground_state.res_mfe[j][i])*Kcal2unit
         if E>0: color  = weighted_color(POSITIVE, E/cscale)
         else:   color  = weighted_color(NEGATIVE, -E/cscale)
         tmpstr += '<td align = "right" bgcolor=%s>%4.2f</td>\n' % (color, E)
         if aE < abs(E): aE=abs(E)

         if form["ib"].value != residues[j][0]: 
            url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=resmfe&value=%s&ia=%s&ib=%s&ea=%s&eb=%s'%(form["value"].value, form["ia"].value, residues[j][0], form["ea"].value, form["eb"].value)
            icon = '<img src=/mcceimages/right_u.gif border=0>'
            tmpstr += '<td><a href=%s>%s</a></td>' % (url, icon)
         else:
            icon = '<img src=/mcceimages/right_p.gif border=0>'
            tmpstr += '<td>%s</td>' % icon

         tmpstr += '</tr>\n'

         if aE > refine_mfe: outstr+=tmpstr

   outstr += '</tbody>\n'
   outstr += '</table>\n'

   outstr += '</td>' # end of the left lower portion

   # Right portion
   outstr += '<td  valign=top width=50%>' # start of the right lower portion
   outstr += 'Analysis on specific term, pH and Eh'
   outstr += '<table cellpadding="1" cellspacing="1" border="2" width=100%>\n'
   outstr += '<tbody>\n'

   ia = int(form["ia"].value)
   found = 0
#HERE   url = CGI+'directory=_DIRECTORY_&name=_NAME_&action=confmfe&value=%s'
   # vdw0 section   
   if   form["ib"].value == "vdw0":
      txt = 'vdw0'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw0*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw0*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.vdw0[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw0*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw0*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.vdw0[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.vdw0[ia]-dG.ground_state.vdw0[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
      
   # vdw1 section
   elif form["ib"].value == "vdw1":
      txt = 'vdw1'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw1*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw1*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.vdw1[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw1*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.vdw1*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.vdw1[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.vdw1[ia]-dG.ground_state.vdw1[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # tors section
   elif form["ib"].value == "tors":
      txt = 'tors'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.tors*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.tors*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.tors[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % (conformer.nocc[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % conformer.tors
         outstr += '<td align=right>%.2f</td>\n' % (conformer.tors*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.tors[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.tors[ia]-dG.ground_state.tors[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # epol section
   elif form["ib"].value == "epol":
      txt = 'epol'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.epol*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.epol*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.epol[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.epol*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.epol*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.epol[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.epol[ia]-dG.ground_state.epol[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # dsolv section
   elif form["ib"].value == "dsolv":
      txt = 'dsolv'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.dsolv*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.dsolv*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.dsolv[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.dsolv*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.dsolv*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.dsolv[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.dsolv[ia]-dG.ground_state.dsolv[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1

   
   # offset section
   elif form["ib"].value == "offset":
      txt = 'offset'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.extra*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.extra*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.extra[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>\n'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.extra*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.extra*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.extra[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.extra[ia]-dG.ground_state.extra[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # pH section
   elif form["ib"].value == "pH":
      txt = 'pH_effect'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.pHeffect[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.pHeffect[ia]*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.pHeffect[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>\n'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.pHeffect[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.pHeffect[ia]*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.pHeffect[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.pHeffect[ia]-dG.ground_state.pHeffect[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # Eh section
   elif form["ib"].value == "Eh":
      txt = 'Eh_effect'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.Eheffect[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.Eheffect[ia]*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.Eheffect[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>\n'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.Eheffect[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.Eheffect[ia]*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.Eheffect[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.Eheffect[ia]-dG.ground_state.Eheffect[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # -TS section
   elif form["ib"].value == "TS":
      txt = 'ln(Pi)'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         if conformer.nocc[ia] > 0.000001: lnPi = math.log(conformer.nocc[ia])
         else: lnPi = 0.0
         outstr += '<td align=right>%.2f</td>\n' % (lnPi)
         outstr += '<td align=right>%.2f</td>\n' % (lnPi*conformer.nocc[ia]/Kcal2kT*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state -TS = Sum(Pi*lnPi)</td>\n'
      outstr += '<td align=right>%.2f</td>\n' % (-dG.ground_state.TS[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>\n'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         if conformer.nocc[ia] > 0.000001: lnPi = math.log(conformer.nocc[ia])
         else: lnPi = 0.0         
         outstr += '<td align=right>%.2f</td>\n' % (lnPi)
         outstr += '<td align=right>%.2f</td>\n' % (lnPi*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state -TS = Sum(Pi*lnPi)</td>\n'
      outstr += '<td align=right>%.2f</td>\n' % (-dG.charged_state.TS[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta -TS</b></td>\n' 
      outstr += '<td align=right><b>%.2f</b></td>\n' % (-(dG.charged_state.TS[ia]-dG.ground_state.TS[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1

   
   # residue section
   elif form["ib"].value == "residues":
      txt = 'Residues'
      outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
      outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
      outstr += '</tr>\n'
      
      for conformer in dG.ground_confs:
         outstr += '<tr>'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.mfe_total[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.mfe_total[ia]*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Groud state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.mfe_total[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      for conformer in dG.charged_confs:
         outstr += '<tr>\n'
         outstr += '<td>%s</td>\n' % conformer.id
         outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
         outstr += '<td align=right>%.2f</td>\n' % (conformer.mfe_total[ia]*Kcal2unit)
         outstr += '<td align=right>%.2f</td>\n' % (conformer.mfe_total[ia]*conformer.nocc[ia]*Kcal2unit)
         outstr += '</tr>\n'
      outstr += '<tr bgcolor=%s>\n' % separate_color
      outstr += '<td colspan=3>Charged state %s sum</td>\n' % txt
      outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.mfe_total[ia]*Kcal2unit)         
      outstr += '</tr>\n'
      
      outstr += '<tr>\n'
      outstr += '<td colspan=3><b>Delta %s sum</b></td>\n' % txt
      outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.mfe_total[ia]-dG.ground_state.mfe_total[ia])*Kcal2unit)         
      outstr += '</tr>\n'
      
      found = 1
   
   # details section 
   if not found:	# show details, search residues
      for i in range(len(residues)):
         if found: break
         if form["ib"].value == residues[i][0]: # see this residue
            txt = 'PW[%s]' % residues[i][0]
            outstr += '<tr bgcolor=%s><td align=left>%s</td>\n' % (separate_color, txt)
            outstr += '<td>Pi</td><td>%s</td><td>Pi*%s</td>\n' % (txt, txt)
            outstr += '</tr>\n'
      
            for conformer in dG.ground_confs:
               outstr += '<tr>'
               outstr += '<td>%s</td>\n' % conformer.id
               outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
               outstr += '<td align=right>%.2f</td>\n' % (conformer.res_mfe[i][ia]*Kcal2unit)
               outstr += '<td align=right>%.2f</td>\n' % (conformer.res_mfe[i][ia]*conformer.nocc[ia]*Kcal2unit)
               outstr += '</tr>\n'
            outstr += '<tr bgcolor=%s>\n' % separate_color
            outstr += '<td colspan=3>Groud state %s</td>\n' % txt
            outstr += '<td align=right>%.2f</td>\n' % (dG.ground_state.res_mfe[i][ia]*Kcal2unit)         
            outstr += '</tr>\n'
      
            for conformer in dG.charged_confs:
               outstr += '<tr>\n'
               outstr += '<td>%s</td>\n' % conformer.id
               outstr += '<td align=right>%.2f</td>\n' % conformer.nocc[ia]
               outstr += '<td align=right>%.2f</td>\n' % (conformer.res_mfe[i][ia]*Kcal2unit)
               outstr += '<td align=right>%.2f</td>\n' % (conformer.res_mfe[i][ia]*conformer.nocc[ia]*Kcal2unit)
               outstr += '</tr>\n'
            outstr += '<tr bgcolor=%s>\n' % separate_color
            outstr += '<td colspan=3>Charged state %s</td>\n' % txt
            outstr += '<td align=right>%.2f</td>\n' % (dG.charged_state.res_mfe[i][ia]*Kcal2unit)         
            outstr += '</tr>\n'
                  
            outstr += '<tr>\n'
            outstr += '<td colspan=3><b>Delta %s</b></td>\n' % txt
            outstr += '<td align=right><b>%.2f</b></td>\n' % ((dG.charged_state.res_mfe[i][ia]-dG.ground_state.res_mfe[i][ia])*Kcal2unit)         
            outstr += '</tr>\n'
         
            found = 1

              

   outstr += '</td></tr>' # end of the right lower portion
   outstr += '</tbody>\n'
   outstr += '</table>\n'
   outstr += '</pre>\n'


   outpage = PROTOTYPE_resmfe.replace("_OUTSTR_", outstr)

   outpage = update_links(outpage)
   print outpage

   return

if __name__ == '__main__':
   global show_status, mfe_status, refine_index
   global refine_mfe
   global cscale
   global residues

   #print 'Content-Type: text/html\n\n'

   # read run.prm
   first_ph()

   #read head list
   read_headlst()

   # read pK.out
   pK = read_pK()

   # read fort.38
   read_fort38()

   residues = group_residues()

   in_cookie = Cookie.SimpleCookie(os.environ.get("HTTP_COOKIE", ""))
   # get mcce index page cookie
   if in_cookie.has_key("mcce"):
      cookie_value = in_cookie["mcce"].value.split(":")
      if cookie_value[0] == form["directory"].value:
         if len(cookie_value[1]) == len(residues): # matched
            show_status = [x for x in cookie_value[1]]
         else:
            show_status = ['f' for i in range(len(residues))]
         if len(cookie_value)>2: refine_index = float(cookie_value[2])
      else:
         show_status = ['f' for i in range(len(residues))]
   else:
      show_status = ['f' for i in range(len(residues))]

   # get mfe display cookie
   if in_cookie.has_key("refine_mfe"):
      cookie_value = in_cookie["refine_mfe"].value.split(":")
      if cookie_value[0] == form["directory"].value:
         refine_mfe = float(cookie_value[1])
   if in_cookie.has_key("cscale"):
      cscale = float(in_cookie["cscale"].value)
   if in_cookie.has_key("refine_mfe"):
      cookie_value = in_cookie["select_unit"].value.split(":")
      if cookie_value[0] == form["directory"].value:
         unit = cookie_value[1]
   if in_cookie.has_key("mfe_status"):
      cookie_value = in_cookie["mfe_status"].value.split(":")
      if cookie_value[0] == form["directory"].value and form.has_key("value") and cookie_value[1].replace('%2B', '+') == form["value"].value.replace('%2B', '+'):
         if len(cookie_value[2]) == len(residues): # matched
            mfe_status = [x for x in cookie_value[2]]
         else:
            mfe_status = ['f' for i in range(len(residues))]
      else:
         mfe_status = ['f' for i in range(len(residues))]
   else:
      mfe_status = ['f' for i in range(len(residues))]



   if not form.has_key("action") :
      print_index()
   elif form["action"].value == 'toggle_index':
      i = int(form["value"].value)
      if show_status[i] == 'f': show_status[i] = 't'
      else: show_status[i] = 'f'
      print_index()
   elif form["action"].value == 'refine_index':
      if (not form.has_key('refine_index') or form["refine_index"].value.strip() == ''):
         refine_index = -0.001
      else:
         refine_index = float(form["refine_index"].value) - 0.0001 #ensure 0.0 is displayed
      print_index()
   elif form["action"].value == 'expand_index':
      show_status = ['t' for i in range(len(residues))]
      print_index()
   elif form["action"].value == 'collapse_index':
      show_status = ['f' for i in range(len(residues))]
      print_index()
   elif form["action"].value == 'confmfe':
      print_confmfe()
   elif form["action"].value == 'refine_mfe':
      if (not form.has_key('refine_mfe') or form["refine_mfe"].value.strip() == ''):
         refine_mfe = 0.0
      else:
         refine_mfe = float(form["refine_mfe"].value) - 0.0001 #ensure 0.0 is displayed
      if (not form.has_key('select_unit') or form["select_unit"].value.strip() == ''):
         unit = "Kcal/mol"
      else:
         unit = form["select_unit"].value
      if form.has_key("cscale") and form["cscale"].value:
         cscale = float(form["cscale"].value)
      if   form["lastaction"].value == "print_confmfe":
         print_confmfe()
      elif form["lastaction"].value == "print_resmfe":
         print_resmfe()
      else:
         print "Wrong"
   elif form["action"].value == 'view':
      print 'Content-Type: text/plain\n\n'
      print open(form["directory"].value+'/'+form["value"].value).read()
   elif form["action"].value == 'save':
      print 'Content-Type: application/octet-stream\n\n'
      print open(form["directory"].value+'/'+form["value"].value).read()
   elif form["action"].value == 'toggle_mfe':
      i = int(form["i"].value)
      if mfe_status[i] == 'f': mfe_status[i] = 't'
      else: mfe_status[i] = 'f'
      print_confmfe()
   elif form["action"].value == 'expand_mfe':
      mfe_status = ['t' for i in range(len(residues))]
      print_confmfe()
   elif form["action"].value == 'collapse_mfe':
      mfe_status = ['f' for i in range(len(residues))]
      print_confmfe()
   elif form["action"].value == 'resmfe':
      print_resmfe()
