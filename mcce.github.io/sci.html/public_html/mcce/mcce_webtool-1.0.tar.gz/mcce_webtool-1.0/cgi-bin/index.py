#!/usr/bin/python2

from time import localtime, strftime
import cgi, os
import cgitb; cgitb.enable()
from os import path

#########################################################################
## Begin customization section 

## The complete name or IP address of the web server
WebServer = 'WEBSERVER_IP'

## User directories, where MCCE data is located.
BASE_DIR  = 'HOME_DIR'

## Title of the web page.
title     = 'MCCE Energy Analysis Tool - Choose a directory'

## End customization section 
#########################################################################

form = cgi.FieldStorage()
CGI = 'http://%s/cgi-bin/index.py?' % WebServer
MCCE_CGI = 'http://%s/cgi-bin/tools.py?' % WebServer
MCCE_IMG = '/mcceimages/goto.gif'

def print_lineage(absPath):
    tokens = absPath.split('/')
    tokens.pop(0)
    numTokens = len(tokens)
    if tokens[numTokens - 1] == '':
        tokens.pop()
    path = ''
    lineage    = '<p> Directory Lineage <BR>\n' 
    lineage  += '<ol type=1>\n'
    for t in tokens:
        path += '/' + t 
        url   = CGI + 'qwd=%s' % path
        lineage += '  <li><a href="%s">%s</a></li>\n' % (url, path)
    lineage += '</ol></p>\n'
    lineage += '<hr>\n'
    print lineage


def lookup_mcce(dir):
    try:
        result = 1
        head3lst = open( dir + '/head3.lst' ).readlines()
        fort38 = open( dir + '/fort.38' ).readlines()
        head3lst.pop(0)
        fort38.pop(0)
        if ( len(fort38) != len(head3lst) ):
            result = -1
        else:
            for i in range(len(fort38)):
                col1 = fort38[i].split()
                col2 = head3lst[i].split()
                if col1[0] != col2[1]:
                    result = -1
                    break
        return result
    except:
        return -1


def print_header(title):
    header  = '<html>\n'
    header += '<head>\n'
    header += '<title>' + title + '</title>\n</head>\n'
    header += '<body>'
    print header

def print_trailer():
    updated  = strftime("%a, %d %b %Y %H:%M:%S", localtime())
    trailer  = '<hr>\n'
    trailer += '<table border="0" width="100%">\n'
    trailer += '  <tr>\n'
    trailer += '    <td>\n'
    trailer += "      Copyright &copy;&nbsp;Gunner's Group 2003\n     </td>\n"
    trailer += '    <td><div align="right">\n'
    trailer += '      <i>Last Updated: %s</i>\n' % updated 
    trailer += '    </div></td>\n'
    trailer += '  </tr>\n'
    trailer += '</table>\n'
    trailer += '</body></html>\n'
    print trailer


def getSubDir(iwd):
    subdir = []
    if os.access(iwd, os.R_OK) == 1:
       allFiles = os.listdir(iwd)
       subdir = [ x for x in allFiles if os.path.isdir( iwd+'/'+x ) ]
       subdir = [ x for x in subdir if x[0] != '.' ]
    return subdir


def excludeHiddenDir(dirlist):
    normalDir = []
    for dir in dirlist:
        if dir[0] != '.':
            normalDir.append(dir)
    return normalDir


def print_heading():
    message  = '<h1> %s </h1>\n' % title
    print message


def print_body():
    message  = '<p>Click on the link to lookup the directory, '
    message += ' click on <img src=%s> to view results.</p>\n' % MCCE_IMG
    message += '<ul>\n'
    subdir = getSubDir(qwd)
    subdir = excludeHiddenDir(subdir)
    subdir.sort()
    for dir in subdir:
        absoluteDir = qwd + '/' + dir
        url = CGI + 'qwd=%s' % (absoluteDir)
        childDir = getSubDir(absoluteDir)  # does this dir has any child dir?
        normalChildDir = excludeHiddenDir( childDir )
        if len( normalChildDir ) != 0:
            if lookup_mcce(absoluteDir) == 1:
                mcceURL = MCCE_CGI + 'directory=%s&name=%s' % (absoluteDir, dir)
                message += '  <li><a href="%s">%s</a> \n' % (url, dir)
                message += ' <a href="%s"><img src="%s" border=0></a></li>\n' % (mcceURL, MCCE_IMG)
            else:
                message += '  <li><a href="%s">%s</a></li>\n' % (url, dir)
        #else:
        #    message += '  <li>%s</li>\n' % dir
    message += '</ul>\n'
    print message


if __name__ == '__main__':
    print 'Content-type: text/html\n\n'
    if (not form.has_key('qwd') or form["qwd"].value.strip() == ''):
        qwd = BASE_DIR
    else:
        qwd = form["qwd"].value

    print_header(title)
    print_heading()
    print_lineage(qwd)
    print_body()
    print_trailer()
    
